L=[0,1,2,3]
# n=int(input("Enter: "))