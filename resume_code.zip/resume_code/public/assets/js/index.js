var items =document.getElementById("ui");

function textA()
{
    for (var j=0;j<42;j++)
    {
        items.innerHTML += `<div class="text">Agrim Kulshreshtha</div>`
    }
}

var items2 =document.getElementById("wrapper");

function textA2()
{
    items2.innerHTML += `<h1>Agrim Kulshreshtha</h1>`

}

let width = screen.width;
if (width> 1199 )  {
    items2.innerHTML=''

textA()
}
else{
    items.innerHTML=''
    console.log("hi")
    textA2()
}