# n=int(input("Enter: "))
# # for i in range(1,n+1):
# print(1)

# for j in range (int(n/2),0,-1):
#     print(j,end="")
# print()

# for j in range (int((n/2)/2),0,-1):
#     print(j,end="")
# print()

# for j in range(1,int(n/2)):
#     print(j,end="")
# print()
# for j in range(1,int(n/2)):
#     print(j,end="")
# print()
# for j in range (int((n/2)/2),0,-1):
#     print(j,end="")
# print()
# for j in range (int(n/2),0,-1):
#     print(j,end="")
# print()
# print(1)



def test():

    if x==0:
        print(1)

    if x==1:
        for j in range (int(n/2),0,-1):
            print(j,end="")
        print()


    if x==2:
        for j in range (int((n/2)/2),0,-1):
            print(j,end="")
        print()


    if x==3:
        for j in range(1,int(n/2)):
            print(j,end="")
        print()

L=[0,1,2,3,3,2,1,0]
n=int(input("Enter: "))
for x in L:
    test()
# for i in range(3,-1,-1):
#     x=L[i]
#     test()

# L=[0,1,2,3]
# n=int(input("Enter: "))
# for i,j in zip(L,reversed(L)):
#     print(i,j)
#     # test()