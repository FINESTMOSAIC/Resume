#Coded By FinestMosaic69 aka Agrim Kulshreshtha

import cv2
import mediapipe as mp
import numpy as np

# Create a HandDetector class (assuming you have implemented it)
class HandDetector:
    def __init__(self):
        self.hand_recognition_enabled = True

    def disableHandRecognition(self):
        self.hand_recognition_enabled = False

    def enableHandRecognition(self):
        self.hand_recognition_enabled = True

    # Add other methods as needed...

# Initialize MediaPipe hands
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# Create a HandDetector instance
detector = HandDetector()

# OpenCV initial setup
cap = cv2.VideoCapture(0)
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Create a blank canvas
canvas = np.zeros((height, width, 3), dtype=np.uint8)
selected_color = (0, 255, 0)  # Default color (Green)

with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7, min_tracking_confidence=0.7) as hands:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Flip the frame horizontally for a later selfie-view display
        frame = cv2.flip(frame, 1)
        # Convert the BGR image to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # Process the frame
        results = hands.process(rgb_frame)

        # Draw landmarks and lines if hand is detected
        if results.multi_hand_landmarks and detector.hand_recognition_enabled:
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw hand landmarks
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Get index fingertip landmark
                index_finger_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
                x = int(index_finger_tip.x * width)
                y = int(index_finger_tip.y * height)

                # Draw on canvas based on index fingertip movement
                cv2.circle(canvas, (x, y), 10, selected_color, -1)
        combined = cv2.addWeighted(frame, 1, canvas, 0.5, 0)
        # Display the frame and canvas
        cv2.imshow('Camera & Drawing', combined)

        # Check for key press events
        key = cv2.waitKey(1)
        if key & 0xFF == ord('q'):
            break
        elif key == ord('r'):  # Change color to Red
            selected_color = (0, 0, 255)
        elif key == ord('g'):  # Change color to Green
            selected_color = (0, 255, 0)
        elif key == ord('b'):  # Change color to Blue
            selected_color = (255, 0, 0)
        elif key== ord('y'):#custom added
            selected_color=(255,255,255)
        
        elif key==ord('z'):#custom added
            selected_color=(254,50,185)

        elif key == ord('f'): #custom added
            selected_color = (124 ,134, 0)
        elif key == ord('e'):  # Eraser
            selected_color = (0, 0, 0)
        elif key == ord('c'):  # Clear canvas on 'c' key press
            canvas = np.zeros((height, width, 3), dtype=np.uint8)
        elif key == ord('n'):  # Disable hand recognition
            detector.disableHandRecognition()
        elif key == ord('m'):  # Enable hand recognition
            detector.enableHandRecognition()

cap.release()
cv2.destroyAllWindows()
#Coded By FinestMosaic69 aka Agrim Kulshreshtha